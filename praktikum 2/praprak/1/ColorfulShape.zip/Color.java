public class Color {
    private int red;
    private int green;
    private int blue;

    /**
     * Konstruktor Color
     * @param r nilai red (0-255)
     * @param g nilai green (0-255)
     * @param b nilai blue (0-255)
     */
    public Color(int r, int g, int b) {
        // TODO: Print constructor message with format
        // "Color is being built with RGB(r, g, b)"
        // Example: if r=255, g=0, b=0, print "Color is being built with RGB(255, 0, 0)"
        System.out.println("Color is being built with RGB(" + r + ", " + g + ", " + b + ")");
        this.red = r;
        this.green = g;
        this.blue = b;
    }

    @Override
    public String toString() {
        return "RGB(" + red + ", " + green + ", " + blue + ")";
    }

    public int getRed() {
        return red;
    }

    public int getGreen() {
        return green;
    }

    public int getBlue() {
        return blue;
    }

    /**
     * Mengubah nilai warna
     */
    public void setColor(int r, int g, int b) {
        this.red = r;
        this.green = g;
        this.blue = b;
    }
}
