public class Shape {
    private Color color;
    private String name;

    /**
     * Konstruktor Shape
     */
    public Shape(Color color, String name) {
        System.out.println("Shape is being built with color " + color + " and name '" + name + "'");
        this.color = color;
        this.name = name;
    }

    /**
     * Default constructor for Shape
     */
    public Shape() {
        System.out.println("Shape is being built with default color and name 'Default'");
        this.color = new Color(0, 0, 0);
        this.name = "Default";
    }

    /**
     * Constructor with name parameter
     */
    public Shape(String name) {
        System.out.println("Shape is being built with default color and name '" + name + "'");
        this.color = new Color(0, 0, 0);
        this.name = name;
    }

    /**
     * Constructor with RGB parameters
     */
    public Shape(int r, int g, int b) {
        System.out.println("Shape is being built with color RGB(" + r + ", " + g + ", " + b + ") and default name 'Default'");
        this.color = new Color(r, g, b);
        this.name = "Default";
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
